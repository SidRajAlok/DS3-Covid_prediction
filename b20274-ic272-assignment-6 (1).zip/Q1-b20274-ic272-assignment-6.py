## Q1 Alok Raj Sidhaarth  B20274 9870176860

import pandas as pd
from pandas.plotting import lag_plot
import matplotlib.pyplot as py
import numpy as np
import statsmodels.api as sm
from statsmodels.graphics.tsaplots import plot_acf
from statsmodels.tsa.ar_model import AutoReg
from sklearn.metrics import mean_squared_error
import math


df=pd.read_csv("daily_covid_cases.csv")
series = pd.read_csv('daily_covid_cases.csv',parse_dates=['Date'],index_col=['Date'],sep=',')

## part-a
print("Q1-part-A")
py.rcParams['figure.figsize'] = [10, 5]
xticks=[['Feb-20','Apr-20','Jun-20','Aug-20','Oct-20','Dec-20','Feb-21','Apr-21','Jun-21','Aug-21','Oct-21'],[0,60,120,180,240,300,360,420,480,540,600]]
py.plot(df.iloc[:,0],df.iloc[:,1])
py.xticks(xticks[1],xticks[0])
py.title("Q1 Part-A  covid cases per day vs months")
py.show()



## part-b
print("Part-B")
series_1=series.shift(1)
autocorrelation_1=sm.tsa.acf(series,nlags=1)     ## using the statsmodels inbuilt function acf for autocorrelation
print("The autocorrelation for lag-1 is :",autocorrelation_1[1])
print()

## part-c
print("part-C")
py.scatter(series[1:],series_1[1:])
py.xlabel("original")
py.ylabel("time lag=1")
py.title("Q1-Part-C")
py.show()

## part-d
print("part-D")
autocorrelation=sm.tsa.acf(series,nlags=6)
py.plot(['1-day','2-day','3-day','4-day','5-day','6-day'],autocorrelation[1:])
py.xlabel("lag-days")
py.ylabel("Autocorrelation coeff")
py.title("Q1-part-D  lag days vs autocorrcoeff")
py.show()

## part-e
print("part-E")
plot_acf(series,lags=6)
py.title("Q1-part-E correlogram")
py.show()
