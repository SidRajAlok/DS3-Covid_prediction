## Q4 ic272 Alok Raj Sidhaarth  9870176860

import pandas as pd
import matplotlib.pyplot as py
import numpy as np
import math
import statsmodels.api as sm
from statsmodels.graphics.tsaplots import plot_acf
from statsmodels.tsa.ar_model import AutoReg as AR
from sklearn.metrics import mean_squared_error

## data processing. Dividing into test and train
series = pd.read_csv('daily_covid_cases.csv',parse_dates=['Date'],index_col=['Date'],sep=',')
test_size = 0.35                 # 35% for testing
X = series.values
tst_sz = math.ceil(len(X)*test_size)
train, test = X[:len(X)-tst_sz], series[len(X)-tst_sz:]


def autoregressor(p,train,test):
    window = p                         # The lag=p
    model = AR(train, lags=window)
    model_fit = model.fit()            # fit/train the model
    coef = model_fit.params            # Get the coefficients of AR model
 
    history = train[len(train)-window:]
    history = [history[i] for i in range(len(history))]
    predictions = list()                                            # List to hold the predictions, 1 step at a time
    for t in range(len(test)):
        length = len(history)
        lag = [history[i] for i in range(length-window,length)]
        yhat = coef[0]                                                
                                                                   # Append actual test value to history, to be used in next step.
        for d in range(window):
            yhat += coef[d+1] * lag[window-d-1]                             # Add other values
                                                                # Append predictions to compute RMSE later
        predictions.append(yhat)
        obs = test.iloc[t]
        history.append(obs)  
    return predictions


## Q4
print("Q4")

T=len(train)
lags=0               ## initialzising the heuristic number of lags
i=1
while True:
    autocorrelation=sm.tsa.acf(train,nlags=i)
    if(abs(autocorrelation[i])<2/pow(T,0.5)):
       break
    i+=1
    lags+=1
lags=lags-1     # this is because nlags counts the numbe of lag days. This includes lags=0.
print("The heuristic lag value is",lags)

test_arr=np.array(test)

prediction=autoregressor(lags,train,test)     ## using the above obtained value of lags for autoregression
prediction_arr=np.array(prediction)           ## converting series to array for easy calculation
rmspe = float(np.sqrt(np.mean(np.square(test_arr - prediction_arr)))/(sum(test_arr)/len(test_arr))) * 100
mape = float(np.mean(np.abs((test_arr - prediction_arr)/test))*100)    ## using percentage rmse and mape formulas 

print("The RMSE(%) is",rmspe)
print("The MAPE is",mape)
