## Q2 Alok Raj Sidhaarth  B20274  9870176860

import pandas as pd
import matplotlib.pyplot as py
import numpy as np
import math
from statsmodels.tsa.ar_model import AutoReg as AR
from sklearn.metrics import mean_squared_error

## data processing. Dividing into test and train
series = pd.read_csv('daily_covid_cases.csv',parse_dates=['Date'],index_col=['Date'],sep=',')
test_size = 0.35                 # 35% for testing
X = series.values
tst_sz = math.ceil(len(X)*test_size)
train, test = X[:len(X)-tst_sz], series[len(X)-tst_sz:]

## part-a

# plotting train data
xticks=[['Feb-20','Apr-20','Jun-20','Aug-20','Oct-20','Dec-20','Feb-21'],[0,60,120,180,240,300,360]]
x_axis=np.arange(0,len(train))
py.plot(x_axis,train)
py.xticks(xticks[1],xticks[0])
py.xlabel("months")
py.ylabel("cases reported per day")
py.title("Q2 \ntrain data")
py.show()

# plotting test data 
xticks=[['Apr-21','Jun-21','Aug-21','Oct-21'],[0,60,120,180]]
x_axis=np.arange(0,len(test))
py.plot(x_axis,test)
py.xticks(xticks[1],xticks[0])
py.xlabel("months")
py.ylabel("cases reported per day")
py.title("Q2 \ntest data")
py.show()


def autoregressor(p,train,test):
    window = p                         # The lag=p
    model = AR(train, lags=window)
    model_fit = model.fit()            # fit/train the model
    coef = model_fit.params            # Get the coefficients of AR model
 
    history = train[len(train)-window:]
    history = [history[i] for i in range(len(history))]
    predictions = list()                                            # List to hold the predictions, 1 step at a time
    for t in range(len(test)):
        length = len(history)
        lag = [history[i] for i in range(length-window,length)]
        yhat = coef[0]                                                
                                                                   # Append actual test value to history, to be used in next step.
        for d in range(window):
            yhat += coef[d+1] * lag[window-d-1]                             # Add other values
                                                                # Append predictions to compute RMSE later
        predictions.append(yhat)
        obs = test.iloc[t]
        history.append(obs)  
    return predictions,coef

test_arr=np.array(test)            ## converting the test series to numpy array for easy calculation

prediction,coeff=autoregressor(5,train,test)
print("The coefficients are :",coeff)
print()

prediction_arr=np.array(prediction)

## Part-b -i
print("part-b-i")
py.scatter(test_arr,prediction_arr)
py.xlabel("actual data")
py.ylabel("predicted data")
py.title("Q2 part-b-i \n scatter plot between original and predicted data")
py.show()

## Part-b -ii
print("part-b-ii")
py.plot(x_axis,test_arr,label="original")
py.plot(x_axis,prediction_arr,label="predicted")
py.xlabel("days")
py.ylabel("actual and predicted data")
py.legend()
py.title("Q2 part-b-ii \n scatter plot of actual and predicted data")
py.show()

## part-b iii
print("part-b-iii")
rmspe = float(np.sqrt(np.mean(np.square(test_arr - prediction_arr)))/(sum(test_arr)/len(test_arr))) * 100
mape = float(np.mean(np.abs((test_arr - prediction_arr)/test))*100)    ## using percentage rmse and mape formulas 
print("rmspe is:",rmspe)
print("mape is:",mape)
