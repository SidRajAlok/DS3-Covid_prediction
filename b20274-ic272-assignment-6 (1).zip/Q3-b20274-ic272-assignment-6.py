## Q3 Alok Raj Sidhaarth  B20274 9870176860

import pandas as pd
import matplotlib.pyplot as py
import numpy as np
import math
from statsmodels.tsa.ar_model import AutoReg as AR
from sklearn.metrics import mean_squared_error

## data processing. Dividing into test and train
series = pd.read_csv('daily_covid_cases.csv',parse_dates=['Date'],index_col=['Date'],sep=',')
test_size = 0.35                 # 35% for testing
X = series.values
tst_sz = math.ceil(len(X)*test_size)
train, test = X[:len(X)-tst_sz], series[len(X)-tst_sz:]


def autoregressor(p,train,test):
    window = p                         # The lag=p
    model = AR(train, lags=window)
    model_fit = model.fit()            # fit/train the model
    coef = model_fit.params            # Get the coefficients of AR model
 
    history = train[len(train)-window:]
    history = [history[i] for i in range(len(history))]
    predictions = list()                                            # List to hold the predictions, 1 step at a time
    for t in range(len(test)):
        length = len(history)
        lag = [history[i] for i in range(length-window,length)]
        yhat = coef[0]                                                
                                                                   # Append actual test value to history, to be used in next step.
        for d in range(window):
            yhat += coef[d+1] * lag[window-d-1]                             # Add other values
                                                                # Append predictions to compute RMSE later
        predictions.append(yhat)
        obs = test.iloc[t]
        history.append(obs)  
    return predictions


print("Q3")

rmspe_list=[]            ## initializing lists for holding rmspe and mape values for various time lags
mape_list=[]
test_arr=np.array(test)  ## converting the pandas series to np.array for easier calculation
for i in [1,5,10,15,25]:
    prediction=autoregressor(i,train,test)
    prediction_arr=np.array(prediction)
    rmspe = float(np.sqrt(np.mean(np.square(test_arr - prediction_arr)))/(sum(test_arr)/len(test_arr))) * 100
    mape = float(np.mean(np.abs((test_arr - prediction_arr)/test))*100)    ## using percentage rmse and mape formulas 
    rmspe_list.append(rmspe)
    mape_list.append(mape)

py.bar([1,5,10,15,25],rmspe_list)
py.xlabel("lags in days")
py.ylabel("rmspe error")
py.title("Q3 Bar Chart \nrmspe vs lag")
py.show()

py.bar([1,5,10,15,25],mape_list)
py.xlabel("lags in days")
py.ylabel("mape")
py.title("Q3 bar Chart \nmape vs lag")
py.show()

print("The rmse(%)(rmspe) and mape are as follow")
error_dict={"rmspe":rmspe_list,"mape":mape_list}
error_data=pd.DataFrame(error_dict).set_index(pd.Series([1,5,10,15,25]))
print(error_data)
